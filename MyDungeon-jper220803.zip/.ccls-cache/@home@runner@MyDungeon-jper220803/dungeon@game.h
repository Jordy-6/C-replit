#ifndef GAME_H
#define GAME_H
#include "stats.h"


void boucle(Person *s);
int fight(Person *s,Person *p);
void rest(Person *s);
#endif