#ifndef PERSONNAGE_H
#define PERSONNAGE_H

typedef struct {
    int hp;     //les points de vie
    int hp_max; //les points de vie maximum
    int atk;    // les points d'attaque
    int def;    // les points de defense 
} Person;

Person *health(hp_max)

#endif

