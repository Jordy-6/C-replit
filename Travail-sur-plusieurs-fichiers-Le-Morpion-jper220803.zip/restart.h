#ifndef RESTART_H
#define RESTART_H

extern void restart_game(char (*grid)[3]);

#endif