#include <stdio.h>
#include "total_point.h"



int score_temp = 0;


int score(char c){
    score_temp++;
  return score_temp;
}



