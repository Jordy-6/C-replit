#ifndef GAME_H
#define GAME_H

extern int test_win(char(*grid)[3], char c);

#endif