#ifndef total_point_H
#define total_point_H

extern int score(char c);


#endif